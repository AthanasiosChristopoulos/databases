-- SELECT generate_level();
-- SELECT create_am(2025,77)
-- SELECT * FROM random_surnames(100);
-- SELECT * FROM random_lab(100);
-- SELECT * FROM generate_rank(100);

-- SELECT * FROM generate_professors(100);
SELECT generate_students(2024, 100);
SELECT s.* FROM "Person" p JOIN "Student" s USING(amka)
ORDER BY p.ctid DESC
LIMIT 100;