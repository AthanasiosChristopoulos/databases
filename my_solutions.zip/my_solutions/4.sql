-- 4)
-- 4.1)

DROP TRIGGER IF EXISTS register_monitor ON "Register";
DROP FUNCTION IF EXISTS register_update();

CREATE OR REPLACE FUNCTION register_update() 
RETURNS TRIGGER AS
$BODY$
BEGIN
    IF (TG_OP = 'UPDATE' OR TG_OP = 'INSERT') THEN
        IF TG_OP = 'UPDATE' AND (OLD.exam_grade <> NEW.exam_grade OR OLD.lab_grade <> NEW.lab_grade) OR TG_OP = 'INSERT' THEN 
		
			IF NEW.exam_grade IS NULL OR NEW.lab_grade IS NULL THEN
                RETURN NEW;  -- Do nothing if grades are NULL
            END IF;
			
			NEW.final_grade := ROUND(((NEW.exam_grade + NEW.lab_grade) / 2)::NUMERIC, 1);

            IF NEW.final_grade >= 5 THEN
                NEW.register_status := 'pass';
            ELSE
                NEW.register_status := 'fail';
            END IF;

            RETURN NEW;
        END IF;
    END IF;

    RETURN NEW;  
END;
$BODY$
LANGUAGE plpgsql;
CREATE TRIGGER register_monitor BEFORE UPDATE OR INSERT ON "Register" 
FOR EACH ROW EXECUTE FUNCTION register_update();

-- UPDATE "Register" r   -- Table to Update
-- SET exam_grade = 5, lab_grade = 10
-- FROM "Student" st     -- Joining Table
-- WHERE st.amka = '28099105058' AND r.course_code = 'ΑΓΓ 101' AND st.amka = r.amka;

-- DELETE FROM "Register"
-- WHERE amka = '28099105058'
-- AND course_code = 'ΠΛΗ 102'
-- AND serial_number = 1;

-- INSERT INTO "Register" (amka, course_code, serial_number, exam_grade, lab_grade) 
-- VALUES ('28099105058', 'ΠΛΗ 102', 1, 5, 3);

-- SELECT * 
-- FROM "Student" st
-- JOIN "Register" r USING(amka)
-- WHERE st.amka = '28099105058';

---------------------------------------------------------------------------------------------------------------

-- 4.2)

DROP TRIGGER IF EXISTS course_monitor ON "Course";
DROP FUNCTION IF EXISTS archive_course();

CREATE OR REPLACE FUNCTION archive_course() RETURNS TRIGGER AS
$BODY$
DECLARE
    new_course_code VARCHAR;
BEGIN
	IF (OLD.course_title <> NEW.course_title OR OLD.course_description <> NEW.course_description) THEN
	    new_course_code := 'OLD_' || OLD.course_code || '_' || TO_CHAR(NOW(), 'YYYYMMDD_HH24MI');
	
	    INSERT INTO "Course"(
	        course_code, course_title, units, lecture_hours, tutorial_hours, lab_hours, 
	        typical_year, typical_season, obligatory, course_description)
	    VALUES (
	        new_course_code, OLD.course_title, OLD.units, OLD.lecture_hours, OLD.tutorial_hours, 
	        OLD.lab_hours, OLD.typical_year, OLD.typical_season, OLD.obligatory, OLD.course_description);
	
	END IF;
	RETURN NEW;
END;
$BODY$
LANGUAGE plpgsql;

CREATE TRIGGER course_monitor BEFORE UPDATE ON "Course" 
FOR EACH ROW EXECUTE PROCEDURE archive_course(); 

---------------------------------------------------------------------------------------------------------------

-- 4.3)

-- Helpful:
-- SELECT v.course_code as passed, b.currently_running as can_register
-- FROM(
-- SELECT cr.course_code AS currently_running, cr.serial_number AS currently_running_number, cd.main, s.academic_year
-- FROM "CourseRun" cr
-- JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id) 
-- LEFT JOIN "Course_depends" cd ON(cd.dependent = cr.course_code) 
-- WHERE s.academic_year = 2025 and s.academic_season = 'spring' and cd.mode = 'required') as b
-- JOIN
-- (SELECT r.*
-- FROM "Register" r
-- WHERE r.amka = '01010206100' and r.register_status = 'pass') as v
-- ON(b.main = v.course_code)

DROP TRIGGER IF EXISTS course_register_monitor ON "Register";
DROP FUNCTION IF EXISTS course_register_trigger();

CREATE OR REPLACE FUNCTION course_register_trigger() RETURNS TRIGGER AS
$BODY$
DECLARE
    new_course_code character varying;
    student_amka character varying; 
    all_units integer;
    number_of_courses integer;
BEGIN
    IF ((TG_OP = 'INSERT' AND NEW.register_status = 'requested') OR (TG_OP = 'UPDATE' AND NEW.register_status = 'proposed')) THEN
        
        -- Capture the AMKA and course_code of the new or updated row
        student_amka := NEW.amka; 
        new_course_code := NEW.course_code;
        
        -- Calculate total units and count of courses registered by the student
        SELECT SUM(c.units)::integer, COUNT(DISTINCT r.course_code)::integer 
        INTO all_units, number_of_courses
        FROM "Register" r
        JOIN "CourseRun" cr USING(course_code)
        JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
        JOIN "Course" c USING(course_code)
        WHERE r.amka = student_amka AND s.semester_status = 'present' AND r.register_status NOT IN ('pass', 'fail');

        -- Check if the student has too many units or courses
        IF all_units >= 20 OR number_of_courses >= 6 THEN
            NEW.register_status := 'rejected';
            RAISE EXCEPTION 'Too many courses for student with AMKA: %', student_amka;
        END IF;

        -- Check if the student has completed the required course for the new course registration
        IF EXISTS (
				SELECT *
				FROM -- Required Courses for new_course_code
				(SELECT cd.main as course_code
				FROM "Course_depends" cd
				WHERE dependent = new_course_code and cd.mode = 'required')
        ) THEN
			RAISE NOTICE 'AAAAA';
		     IF NOT EXISTS (
				SELECT *
				FROM -- Required Courses for new_course_code
				(SELECT cd.main as course_code
				FROM "Course_depends" cd
				WHERE dependent = new_course_code and cd.mode = 'required')
				JOIN -- Passed Courses of student with student_amka
				(SELECT r.course_code
				FROM "Register" r
				WHERE r.amka = student_amka AND r.register_status = 'pass') USING(course_code)
	        ) THEN
	            NEW.register_status := 'rejected';
	            RAISE NOTICE 'Failed to fulfill the requirement for course: % student with AMKA: %', new_course_code, student_amka;
				-- RAISE EXCEPTION 'Failed to fulfill the requirement for course: % student with AMKA: %', new_course_code, student_amka;
				RETURN NEW;
	        END IF;
		END IF;			
		
        NEW.register_status := 'approved';
        
    END IF;

    RETURN NEW;
END;
$BODY$
LANGUAGE plpgsql;

CREATE TRIGGER course_register_monitor 
BEFORE INSERT OR UPDATE ON "Register" 
FOR EACH ROW EXECUTE PROCEDURE course_register_trigger();

---------------------------------------------------------------------------------------------------------------

-- 4.4)

DROP TRIGGER IF EXISTS diploma_monitor ON "Diploma";
DROP FUNCTION IF EXISTS diploma_monitor_trigger();

CREATE OR REPLACE FUNCTION diploma_monitor_trigger() RETURNS TRIGGER AS
$BODY$
DECLARE
    num_of_required_courses integer;
    number_of_passed_courses integer;
	
	number_of_optional_courses integer;
	number_of_passed_optional_courses integer;
	
	number_of_required_units integer;
	number_of_aqcuired_units integer;

BEGIN

    SELECT COUNT(c.course_code) INTO num_of_required_courses
    FROM "Course" c
    WHERE c.obligatory = True;

    SELECT ddd.min_courses - num_of_required_courses INTO number_of_optional_courses
    FROM "DeptRules" ddd
    WHERE ddd.valid_for_year = 2025;
	
    SELECT ddd.min_units INTO number_of_required_units
    FROM "DeptRules" ddd
    WHERE ddd.valid_for_year = 2025;

	-----------------------------------------------------------------------------------------
	
    SELECT COUNT(r.course_code) INTO number_of_passed_courses
    FROM "Course" c
    JOIN "Register" r ON c.course_code = r.course_code  
    WHERE r.amka = NEW.amkagets AND c.obligatory = True AND r.register_status = 'pass';

    -- Count all passed required courses for the student
    SELECT COUNT(r.course_code) INTO number_of_passed_optional_courses
    FROM "Course" c
    JOIN "Register" r ON c.course_code = r.course_code  
    WHERE r.amka = NEW.amkagets AND c.obligatory = False AND r.register_status = 'pass';

    SELECT SUM(c.units) INTO number_of_aqcuired_units
    FROM "Course" c
    JOIN "Register" r ON c.course_code = r.course_code  
    WHERE r.amka = NEW.amkagets AND r.register_status = 'pass';
	
    RAISE NOTICE 'num_of_required_courses: %', num_of_required_courses;
    RAISE NOTICE 'number_of_passed_courses: %', number_of_passed_courses;
	
    RAISE NOTICE 'number_of_optional_courses: %', number_of_optional_courses;
    RAISE NOTICE 'number_of_passed_optional_courses: %', number_of_passed_optional_courses;
	
    RAISE NOTICE 'number_of_required_units: %', number_of_required_units;
    RAISE NOTICE 'number_of_aqcuired_units: %', number_of_aqcuired_units;

	IF (num_of_required_courses >= number_of_passed_courses) THEN
		RAISE EXCEPTION 'No Diploma allowed - Too few required courses';
	END IF;

	IF (number_of_optional_courses >= number_of_passed_optional_courses) THEN
		RAISE EXCEPTION 'No Diploma allowed - Too few optional courses';
	END IF;

	IF (number_of_required_units >= number_of_aqcuired_units) THEN
		RAISE EXCEPTION 'No Diploma allowed - Too few units';
	END IF;

END;
$BODY$
LANGUAGE plpgsql;

CREATE TRIGGER diploma_monitor 
BEFORE INSERT OR UPDATE ON "Diploma" 
FOR EACH ROW EXECUTE PROCEDURE diploma_monitor_trigger();
