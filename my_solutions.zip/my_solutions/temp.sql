-- SELECT course_code FROM "Course";


-- SELECT cd.main as course_code
-- FROM "Course_depends" cd
-- WHERE dependent = 'ΕΝΕ 301' and cd.mode = 'required'
-- '01010206100' => no 'ΕΝΕ 301' cause no 'ΗΡΥ 202' and yes 'ΠΛΗ 301' cause yes 'ΗΡΥ 201'

       -- SELECT SUM(c.units)::integer, COUNT(DISTINCT r.course_code)::integer 
       --  FROM "Register" r
       --  JOIN "CourseRun" cr USING(course_code)
       --  JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
       --  JOIN "Course" c USING(course_code)
       --  WHERE r.amka = '01010206100' AND s.semester_status = 'present' AND r.register_status NOT IN ('pass', 'fail');

-- SELECT r.*
-- FROM "Register" r
-- WHERE r.amka = '01010206100';

-- SELECT r.*
-- FROM "Register" r
-- JOIN "CourseRun" cr USING(course_code)
-- JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
-- JOIN "Course" c USING(course_code)
-- WHERE r.amka = '01010206100' AND s.semester_status = 'present' AND r.register_status NOT IN ('pass', 'fail');

-- DELETE FROM "Register"
-- WHERE amka = '01010206100' AND course_code = 'ΦΥΣ 102';

-- INSERT INTO "Register" (amka, serial_number, course_code, register_status)
-- VALUES ('01010206100', 13, 'ΚΕΠ 302', 'requested')


INSERT INTO "Register" (amka, serial_number, course_code, register_status)
VALUES ('01010206100', 13, 'ΤΗΛ 202', 'requested')
