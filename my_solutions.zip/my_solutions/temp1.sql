-- SELECT * 
-- FROM "Course" c
-- WHERE c.course_code = 'ΑΓΓ 101';

-- UPDATE "Course" c
-- SET units = 6::smallint
-- WHERE c.course_code = 'ΑΓΓ 101';

-- SELECT r.amka, r.course_code, r.register_status, c.units
-- FROM "Register" r
-- JOIN "CourseRun" cr USING(course_code)
-- JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
-- JOIN "Course" c USING(course_code)
-- WHERE r.amka = '01010206100' AND s.semester_status = 'present' AND r.register_status NOT IN ('pass', 'fail');
-- -- WHERE r.amka = '28099105058' AND s.academic_year = 2025 AND c.typical_season = 'spring' AND r.register

-- SELECT r.amka, SUM(c.units) AS all_units, COUNT(DISTINCT r.course_code) AS number_of_courses
-- FROM "Register" r
-- JOIN "CourseRun" cr USING(course_code)
-- JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
-- JOIN "Course" c USING(course_code)
-- WHERE r.amka = '01010206100' AND s.semester_status = 'present' AND r.register_status NOT IN ('pass', 'fail')
-- GROUP BY r.amka


-- SELECT *
-- FROM 
-- -- Required Courses for new_course_code
-- (SELECT cd.main as course_code
-- FROM "Course_depends" cd
-- WHERE dependent = 'ΕΝΕ 301' and cd.mode = 'required')
-- JOIN 
-- -- Passed Courses of student with student_amka
-- (SELECT r.course_code
-- FROM "Register" r
-- WHERE r.amka = '01010206100' AND r.register_status = 'pass') USING(course_code);
-- '01010206100' => no 'ΕΝΕ 301' cause no 'ΗΡΥ 202' and yes 'ΠΛΗ 301' cause yes 'ΗΡΥ 201'


-- (SELECT cd.main as course_code
-- FROM "Course_depends" cd
-- WHERE dependent = 'ΠΛΗ 301' and cd.mode = 'required')

        -- SELECT *
        -- FROM "Register" r
        -- JOIN "CourseRun" cr USING(course_code)
        -- JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
        -- JOIN "Course" c USING(course_code)
        -- WHERE r.amka = '01010206100' AND s.semester_status = 'present' AND r.register_status NOT IN ('pass', 'fail');
