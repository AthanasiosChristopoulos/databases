DO $$ 
DECLARE
    num_of_required_courses integer;
    number_of_passed_courses integer;
	
	number_of_optional_courses integer;
	number_of_passed_optional_courses integer;
	
	number_of_required_units integer;
	number_of_aqcuired_units integer;


BEGIN
    -- Count all required courses
    SELECT COUNT(c.course_code) INTO num_of_required_courses
    FROM "Course" c
    WHERE c.obligatory = True;

    SELECT ddd.min_courses - num_of_required_courses INTO number_of_optional_courses
    FROM "DeptRules" ddd
    WHERE ddd.valid_for_year = 2025;
	
    SELECT ddd.min_units INTO number_of_required_units
    FROM "DeptRules" ddd
    WHERE ddd.valid_for_year = 2025;

	-----------------------------------------------------------------------------------------
    -- Count all passed required courses for the student
    SELECT COUNT(r.course_code) INTO number_of_passed_courses
    FROM "Course" c
    JOIN "Register" r ON c.course_code = r.course_code  
    WHERE r.amka = '01010206100' AND c.obligatory = True AND r.register_status = 'pass';

    -- Count all passed required courses for the student
    SELECT COUNT(r.course_code) INTO number_of_passed_optional_courses
    FROM "Course" c
    JOIN "Register" r ON c.course_code = r.course_code  
    WHERE r.amka = '01010206100' AND c.obligatory = False AND r.register_status = 'pass';

    SELECT SUM(c.units) INTO number_of_aqcuired_units
    FROM "Course" c
    JOIN "Register" r ON c.course_code = r.course_code  
    WHERE r.amka = '01010206100' AND r.register_status = 'pass';
	
    RAISE NOTICE 'num_of_required_courses: %', num_of_required_courses;
    RAISE NOTICE 'number_of_passed_courses: %', number_of_passed_courses;
	
    RAISE NOTICE 'number_of_optional_courses: %', number_of_optional_courses;
    RAISE NOTICE 'number_of_passed_optional_courses: %', number_of_passed_optional_courses;
	
    RAISE NOTICE 'number_of_required_units: %', number_of_required_units;
    RAISE NOTICE 'number_of_aqcuired_units: %', number_of_aqcuired_units;

	IF (num_of_required_courses >= number_of_passed_courses) THEN
		RAISE EXCEPTION 'No Diploma allowed - Too few required courses';
	END IF;

	IF (number_of_optional_courses >= number_of_passed_optional_courses) THEN
		RAISE EXCEPTION 'No Diploma allowed - Too few optional courses';
	END IF;

	IF (number_of_required_units >= number_of_aqcuired_units) THEN
		RAISE EXCEPTION 'No Diploma allowed - Too few units';
	END IF;
END $$ LANGUAGE plpgsql;
