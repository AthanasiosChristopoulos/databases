-- 3)

-- 3.1)

DROP FUNCTION IF EXISTS find_max_professor(integer,semester_season_type);
CREATE OR REPLACE FUNCTION find_max_professor(year integer, typical_season_1 semester_season_type)
RETURNS TABLE (amka character varying, email character varying) AS $$
BEGIN
    RETURN QUERY
	SELECT p.amka, pep.email
	FROM "Professor" p JOIN "Person" pep USING(amka)
	JOIN "Teaches" t USING(amka)
	JOIN "CourseRun" cr USING(course_code)
	JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
	JOIN "Course" c USING(course_code)
	WHERE s.academic_year <> year AND s.academic_season <> typical_season_1  
	GROUP BY p.amka, pep.email
	HAVING COUNT(*) >= ALL(	SELECT COUNT(*)
							FROM "Professor" p JOIN "Person" pep USING(amka)
							JOIN "Teaches" t USING(amka)
							JOIN "CourseRun" cr USING(course_code)
							JOIN "Semester" s ON(cr.semesterrunsin = s.semester_id)
							JOIN "Course" c USING(course_code)
							WHERE s.academic_year <> year AND s.academic_season <> typical_season_1
							GROUP BY p.amka);
END;
$$ LANGUAGE plpgsql VOLATILE;

-- SELECT * FROM find_max_professor(2025, 'spring');

---------------------------------------------------------------------------------------------------------------------------------

-- 3.2)

DROP FUNCTION IF EXISTS find_statistics1(smallint, semester_season_type);
CREATE OR REPLACE FUNCTION find_statistics1(typical_year_1 smallint, typical_season_1 semester_season_type)
RETURNS TABLE (percentage numeric, course_code character varying) AS $$
BEGIN
    RETURN QUERY
    SELECT 
		ROUND((COUNT(CASE WHEN r.final_grade >= 8.5 THEN 1 END) * 1.0 / COUNT(r.final_grade)) * 100, 2) AS percentage,
		r.course_code::character varying
    FROM "Student" s 
    JOIN "Register" r USING(amka)
    WHERE r.register_status <> 'fail'
    GROUP BY r.course_code;
END;
$$ LANGUAGE plpgsql VOLATILE;

-- SELECT * FROM find_statistics1( 2::smallint, 'spring'::semester_season_type);

---------------------------------------------------------------------------------------------------------------------------------

-- 3.3)

DROP FUNCTION IF EXISTS find_load(integer,semester_season_type);
CREATE OR REPLACE FUNCTION find_load(year integer, typical_season_1 semester_season_type)
RETURNS TABLE (am character varying, load numeric) AS $$
BEGIN
    RETURN QUERY
    SELECT s.am::character varying, (SUM(c.lecture_hours) + SUM(c.lab_hours) + SUM(c.tutorial_hours))::numeric as load
	FROM "Student" s 
	JOIN "Register" r USING(amka)
	JOIN "CourseRun" cr USING(course_code)
	JOIN "Course" c USING(course_code)
	JOIN "Semester" ss ON(cr.semesterrunsin = ss.semester_id)
	WHERE ss.academic_year = year AND ss.academic_season = typical_season_1 AND ss.semester_status = 'present'
	GROUP BY s.am;
END;
$$ LANGUAGE plpgsql VOLATILE;

---------------------------------------------------------------------------------------------------------------------------------

-- 3.4)

DROP FUNCTION IF EXISTS find_students(integer,semester_season_type);
CREATE OR REPLACE FUNCTION find_students(year integer, typical_season_1 semester_season_type)
RETURNS TABLE (am character varying, amka character varying) AS $$
BEGIN
    RETURN QUERY
	SELECT s.am::character varying, s.amka::character varying
	FROM "Student" s 
	JOIN "Register" r USING(amka)
	JOIN "CourseRun" cr USING(course_code)
	JOIN "Course" c USING(course_code)
	JOIN "Semester" ss ON cr.semesterrunsin = ss.semester_id
	JOIN (	SELECT r.course_code, AVG(r.final_grade) as avg_1
		    FROM "Register" r
		    JOIN "CourseRun" cr USING(course_code)
			JOIN "Course" cc USING(course_code)
		    JOIN "Semester" ss ON cr.semesterrunsin = ss.semester_id
		    WHERE ss.academic_year = year AND ss.academic_season = typical_season_1 AND ss.semester_status = 'present'
		    GROUP BY r.course_code) as avg_score ON r.course_code = avg_score.course_code 
		
	WHERE ss.academic_year = year AND ss.academic_season = typical_season_1 AND ss.semester_status = 'present' 
		AND r.register_status = 'pass' AND r.final_grade > avg_score.avg_1 
	GROUP BY s.am, s.amka;
END;
$$ LANGUAGE plpgsql VOLATILE;

-- SELECT * FROM find_students(2025::integer, 'spring'::semester_season_type);

---------------------------------------------------------------------------------------------------------------------------------

-- 3.5)

-- DROP FUNCTION IF EXISTS find_course_dependencies(character varying);
CREATE OR REPLACE FUNCTION find_course_dependencies(course_code_1 character varying)
RETURNS TABLE (dependent_12 character varying) AS $$
BEGIN
    RETURN QUERY
	WITH RECURSIVE
	    Anc(main, dependent) AS (
	        SELECT main, dependent
	        FROM "Course_depends"
	        UNION
	        SELECT Anc.main, cd.dependent
	        FROM Anc JOIN "Course_depends" cd
	        ON Anc.dependent = cd.main
	    )
	SELECT dependent::character varying AS dependent_12
	FROM Anc
	WHERE main = course_code_1;

END;
$$ LANGUAGE plpgsql VOLATILE;

-- SELECT find_course_dependencies('ΠΛΗ 101'::character varying);

---------------------------------------------------------------------------------------------------------------------------------

-- 3.6)

DROP FUNCTION IF EXISTS find_good_students(integer,semester_season_type);
CREATE OR REPLACE FUNCTION find_good_students(year integer, typical_season_1 semester_season_type)
RETURNS TABLE (am character varying) AS $$
BEGIN
    RETURN QUERY
	SELECT s.am::character varying
	FROM "CourseRun" cr
	JOIN "Course" c ON(c.course_code = cr.course_code)-- SELECT 2025 - 5(LEFT(am, 4))::int AS am_first FROM public."Student"
	JOIN "Semester" ss ON cr.semesterrunsin = ss.semester_id	
	JOIN "Register" r ON(cr.course_code = r.course_code)
	JOIN "Student" s USING(amka)
	WHERE ss.academic_year = year AND ss.academic_season = typical_season_1  AND ss.semester_status = 'present' 
		AND c.obligatory = True AND r.register_status = 'pass'
	GROUP BY s.am
	HAVING COUNT(*) = (	SELECT COUNT(*)
						FROM "CourseRun" cr
						JOIN "Course" c ON(c.course_code = cr.course_code)
						JOIN "Semester" ss ON cr.semesterrunsin = ss.semester_id	
						WHERE ss.academic_year = year AND ss.academic_season = typical_season_1  AND ss.semester_status = 'present' 
							AND c.obligatory = True);
END;
$$ LANGUAGE plpgsql VOLATILE;

SELECT * FROM find_good_students(2025::integer, 'spring'::semester_season_type);
