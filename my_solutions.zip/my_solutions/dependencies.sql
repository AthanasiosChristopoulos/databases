DELETE FROM public."Student";
DELETE FROM public."LabTeacher";
DELETE FROM public."Professor";
DELETE FROM public."Person";


-- SELECT * FROM "Student"