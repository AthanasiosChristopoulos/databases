CREATE OR REPLACE FUNCTION RANDOM_SURNAMES(N INTEGER) RETURNS TABLE (SURNAME CHARACTER VARYING, ID INTEGER) AS $$
BEGIN
	RETURN QUERY 
	SELECT snam.surname, row_number() OVER ()::integer
	FROM (SELECT "Surname".surname
		  FROM "Surname"
		  ORDER BY random() LIMIT n) as snam; 
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION RANDOM_NAMES(N INTEGER) RETURNS TABLE (NAME CHARACTER VARYING, ID INTEGER) AS $$
BEGIN
	RETURN QUERY 
	SELECT snam.name, row_number() OVER ()::integer
	FROM (SELECT "Name".name
		  FROM "Name"
		  ORDER BY random() LIMIT n) as snam; 
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION random_name() RETURNS TABLE (NAME CHARACTER VARYING) AS $$
BEGIN
	RETURN QUERY 
	SELECT nnn.name
	FROM "Name" nnn
	ORDER BY random() 
	LIMIT 1; 
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION random_surname() RETURNS TABLE (NAME CHARACTER VARYING) AS $$
BEGIN
	RETURN QUERY 
	SELECT nnn.name
	FROM "Surname" nnn
	ORDER BY random() 
	LIMIT 1; 
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION random_father_name() RETURNS TABLE (NAME CHARACTER VARYING) AS $$
BEGIN
	RETURN QUERY 
	SELECT nnn.name
	FROM "Name" nnn
	WHERE nnn.sex = 'M'
	ORDER BY random() 
	LIMIT 1; 
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

-- CREATE OR REPLACE FUNCTION generate_amka(N INTEGER)
-- RETURNS TABLE (amka character varying) AS $$
-- BEGIN
--     RETURN QUERY
--     SELECT DISTINCT lpad(floor(random() * 100000000000)::text, 11, '0')::character varying
--     FROM generate_series(1, N * 10) gs
--     LIMIT N;
-- END;
-- $$ LANGUAGE plpgsql VOLATILE;

CREATE OR REPLACE FUNCTION generate_amka()
RETURNS TABLE (amka character varying) AS $$
BEGIN
    RETURN QUERY
    SELECT DISTINCT lpad(floor(random() * 100000000000)::text, 11, '0')::character varying;
END;
$$ LANGUAGE plpgsql VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION generate_amkas(N INTEGER)
RETURNS TABLE (amka_g character varying) AS $$
DECLARE
    start_amka BIGINT :=  100000000000; -- Starting point for AMKA
						  
BEGIN
    RETURN QUERY
    SELECT 
        lpad((start_amka + gs.id)::text, 11, '0')::character varying
    FROM generate_series(0, N-1) AS gs(id);

END;
$$ LANGUAGE plpgsql VOLATILE;

-- CREATE OR REPLACE FUNCTION generate_amkas(N INTEGER)
-- RETURNS TABLE (amka_g character varying) AS $$
-- DECLARE
--     start_amka BIGINT := 999000000000; -- Starting point for AMKA
-- BEGIN
--     RETURN QUERY
--     WITH new_amkas AS (
--         SELECT 
--             lpad((start_amka + gs.id)::text, 11, '0')::character varying AS amka
--         FROM generate_series(0, N-1) AS gs(id)
--     )
--     SELECT amka_g
--     FROM new_amkas
--     WHERE amka NOT IN (SELECT p.amka FROM "Person" p); -- Ensure that the AMKA is not already in the Person table
-- END;
-- $$ LANGUAGE plpgsql VOLATILE;


----------------------------------------------------------------------------------------------------------------------------

-- CREATE OR REPLACE FUNCTION random_lab(N INTEGER)
-- RETURNS TABLE (lab_code integer) AS $$
-- BEGIN
--     RETURN QUERY
--     SELECT l.lab_code 
--     FROM "Lab" l
--     ORDER BY random()  -- Order rows randomly
--     LIMIT N;           -- Limit to N rows
-- END;
-- $$ LANGUAGE plpgsql VOLATILE;

CREATE OR REPLACE FUNCTION random_lab()
RETURNS TABLE (lab_code integer) AS $$
BEGIN
    RETURN QUERY
    SELECT l.lab_code 
    FROM "Lab" l
    ORDER BY random()  -- Order rows randomly
    LIMIT 1;           -- Limit to N rows
END;
$$ LANGUAGE plpgsql VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION random_date()
RETURNS TABLE (date integer) AS $$
BEGIN
    RETURN QUERY
    SELECT floor(random() * (2024 - 2010 + 1) + 2010)::integer;
END;
$$ LANGUAGE plpgsql VOLATILE;

-----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION random_grade()
RETURNS integer AS $$
BEGIN
    RETURN floor(random() * 10 + 1)::integer;
END;
$$ LANGUAGE plpgsql VOLATILE;

CREATE OR REPLACE FUNCTION random_passing_grade()
RETURNS integer AS $$
BEGIN
    RETURN floor(random() * 6 + 5)::integer;
END;
$$ LANGUAGE plpgsql VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION create_am(year integer, num integer)
RETURNS character(10) AS
$$
BEGIN
	RETURN concat(year::character(4),lpad(num::text,6,'0')); 
END;
$$
LANGUAGE 'plpgsql' IMMUTABLE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION generate_rank()
RETURNS TABLE (rank public.rank_type) AS $$
BEGIN
    RETURN QUERY
    SELECT enumlabel::public.rank_type
    FROM pg_enum
    WHERE enumtypid = 'public.rank_type'::regtype
    ORDER BY random()
    LIMIT 1;
END;
$$ LANGUAGE plpgsql VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION generate_level()
RETURNS TABLE (rank public.level_type) AS $$
BEGIN
    RETURN QUERY
    SELECT enumlabel::public.level_type
    FROM pg_enum
    WHERE enumtypid = 'public.level_type'::regtype
    ORDER BY random()
    LIMIT 1;
END;
$$ LANGUAGE plpgsql VOLATILE;

----------------------------------------------------------------------------------------------------------------------------

	CREATE OR REPLACE FUNCTION greek_to_latin(greek_text text)
RETURNS text LANGUAGE sql AS $$
    SELECT translate(
        greek_text,
        'αβγδεζηθικλμνξοπρστυφχψωάέήίϊΐόύϋΰώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩΆΈΉΊΪΊΌΎΫΰΏ',
        'abgdeziiklmnxoprstufchpswaeiiyioyyoabgdeziiklmnxoprstufchpswaeiiyioyyo'
    );
$$;

----------------------------------------------------------------------------------------------------------------------------
