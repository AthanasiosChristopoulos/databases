-- 1.1) LabTeahers

-- DROP FUNCTION IF EXISTS generate_lab_teachers(integer);

-- CREATE OR REPLACE FUNCTION generate_lab_teachers (N INTEGER) 
-- RETURNS void
-- AS $$
-- BEGIN
--     -- Using WITH to define the generated data CTE
--     WITH generated_data AS (
--         SELECT 
--             n1.name, 
--             s.surname, 
--             generate_amka() AS amka, 
--             random_lab() AS labworks,  -- Adjusted field name to match your insert into LabTeacher
--             generate_level() AS level, 
--             random_name() AS father_name,
--             CONCAT(LOWER(greek_to_latin(s.surname)), '@tuc.gr') AS email
--         FROM random_names(N) n1 
--         JOIN random_surnames(N) s USING (id)
--     )
--     -- Insert into "Person" table
--     INSERT INTO "Person" (amka, name, father_name, surname, email)
--     SELECT amka, name, father_name, surname, email FROM generated_data;

--     -- Insert into "LabTeacher" table using the same generated data CTE
--     INSERT INTO "LabTeacher" (amka, labworks, level)
--     SELECT amka, labworks, level FROM generated_data;
-- END;
-- $$ LANGUAGE 'plpgsql' VOLATILE;

-- SELECT generate_lab_teachers(100);
-- SELECT * FROM "Person";


DROP FUNCTION IF EXISTS generate_lab_teachers(integer);

CREATE OR REPLACE FUNCTION generate_lab_teachers (N INTEGER) 
RETURNS void
AS $$
DECLARE
    v_name character varying;
    v_surname character varying;
    v_amka character varying;
    v_labjoins integer;
    v_level level_type;
    v_father_name character varying;
    v_email character varying;
BEGIN
    FOR i IN 1..N LOOP
        -- Fetch the generated data into variables
        SELECT 
            n1.name, 
            s.surname, 
            nextval('amka_sequence'),
            random_lab(), 
            generate_level(), 
            random_name(),
            CONCAT(LOWER(greek_to_latin(s.surname)), '@tuc.gr')
        INTO 
            v_name,
            v_surname,
            v_amka,
            v_labjoins,
            v_level,
            v_father_name,
            v_email
        FROM random_names(1) n1 
        JOIN random_surnames(1) s USING (id);

		INSERT INTO "Person" (amka, name, father_name, surname, email)
        VALUES (v_amka, v_name, v_father_name, v_surname, v_email);

        INSERT INTO "LabTeacher" (amka, labworks, level)
        VALUES (v_amka, v_labjoins, v_level);
        
		RAISE NOTICE 'Generated LabTeacher - Name: %, Surname: %, AMKA: %', v_name, v_surname, v_amka;

    END LOOP;
END;
$$ LANGUAGE plpgsql;

DO $$ 
BEGIN
    PERFORM generate_lab_teachers(1);
END $$;

	
----------------------------------------------------------------------------------------------------------------------------
-- 1.1) Professors

DROP FUNCTION IF EXISTS generate_professors(integer);
CREATE OR REPLACE FUNCTION generate_professors (N INTEGER) 
RETURNS void
AS $$
BEGIN
    WITH generated_data AS (
        SELECT 
            n1.name, 
            s.surname, 
            generate_amka() AS amka, 
            random_lab() AS labjoins, 
            generate_level() AS level, 
            random_name() AS father_name,
            CONCAT(LOWER(greek_to_latin(s.surname)), '@tuc.gr') AS email
        FROM random_names(N) n1 
        JOIN random_surnames(N) s USING (id)
    )
    INSERT INTO "Person" (amka, name, father_name, surname, email)
    SELECT amka, name, father_name, surname, email FROM generated_data;

    -- INSERT INTO "Professor" (amka, labjoins, rank)
    -- SELECT amka, labjoins, rank FROM generated_data;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

----------------------------------------------------------------------------------------------------------------------------
-- 1.1) Students

DROP FUNCTION IF EXISTS generate_students(integer, integer);
CREATE OR REPLACE FUNCTION generate_students(year integer, N INTEGER) 
RETURNS void
AS $$
BEGIN
    -- Insert data into both Person and Professor tables at once
    WITH generated_data AS (
        SELECT 
            n1.name, 
            s.surname, 
            generate_amka() AS amka, 
            create_am(year,n1.id) AS date, 
           	year AS date, 
            random_name() AS father_name,
            CONCAT(LOWER(greek_to_latin(s.surname)), '@tuc.gr') AS email
        FROM random_names(N) n1 
        JOIN random_surnames(N) s USING (id)
    )
    INSERT INTO "Person" (amka, name, father_name, surname, email)
    SELECT amka, name, father_name, surname, email FROM generated_data;

    -- INSERT INTO "LabTeacher" (amka, labjoins, level)
    -- SELECT amka, labjoins, level FROM generated_data;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

-- SELECT generate_lab_teachers(100);
-- SELECT * FROM "Person";

