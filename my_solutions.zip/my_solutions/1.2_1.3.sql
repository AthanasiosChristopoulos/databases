----------------------------------------------------------------------------------------------------------------------------------
-- 1.2)

CREATE OR REPLACE FUNCTION generate_grade(year integer, typical_season_1 semester_season_type) 
RETURNS void
AS $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN 
        SELECT 
            r.amka, 
            r.course_code, 
            r.serial_number, 
            random_grade() AS new_exam_grade, 
            random_grade() AS new_lab_grade,
            c.lab_hours
        FROM "Register" r
        JOIN "CourseRun" cr ON r.course_code = cr.course_code AND r.serial_number = cr.serial_number
        JOIN "Semester" s ON cr.serial_number = s.semester_id
        JOIN "Course" c ON(c.course_code = r.course_code)
        WHERE s.academic_year = year AND s.academic_season = typical_season_1 AND r.register_status = 'approved'
    LOOP
        IF rec.lab_hours > 0 THEN
            UPDATE "Register" r
            SET 
                exam_grade = rec.new_exam_grade,
                lab_grade = rec.new_lab_grade,
                final_grade = round((rec.new_exam_grade + rec.new_lab_grade) / 2.0),
                register_status = CASE 
                    WHEN round((rec.new_exam_grade + rec.new_lab_grade) / 2.0) < 5 THEN 'fail'
                    ELSE 'pass'
                END
			WHERE r.amka = rec.amka AND r.course_code = rec.course_code AND r.serial_number = rec.serial_number;
        ELSE
            UPDATE "Register" r
            SET 
                exam_grade = rec.new_exam_grade,
                lab_grade = NULL,
                final_grade = round(rec.new_exam_grade),
                register_status = CASE 
                    WHEN round(rec.new_exam_grade) < 5 THEN 'fail'
                    ELSE 'pass'
                END
            WHERE r.amka = rec.amka AND r.course_code = rec.course_code AND r.serial_number = rec.serial_number;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql VOLATILE;


SELECT generate_grade(2025,'spring');

---------------------------------------------------------------------------------------------------------------------------------
-- 1.3) 

CREATE OR REPLACE FUNCTION generate_diploma(am_1 character varying, thesis_title_1 character varying, thesis_description_1 character varying) 
RETURNS void
AS $$
DECLARE
	amka_diploma character varying;
	random_diploma_grade numeric;
	rec RECORD;
	final_diploma_grade numeric;
	id_1 integer; 
	weighted_avg_score numeric;
BEGIN
	SELECT st.amka INTO amka_diploma
	FROM "Student" st 
	WHERE st.am = am_1; 
	
	random_diploma_grade := random_passing_grade()::numeric;
	id_1 := nextval('diploma_id_sequence');
	INSERT INTO "DiplomaWork" (thesis_id, thesis_title, thesis_description, thesis_grade, amkaworks)
	VALUES (id_1, thesis_title_1, thesis_description_1, random_diploma_grade ,amka_diploma);

	SELECT 
        SUM(r.final_grade * 
            CASE 
                WHEN c.units BETWEEN 1 AND 2 THEN 1
                WHEN c.units BETWEEN 3 AND 4 THEN 1.5
                WHEN c.units = 5 THEN 2
                ELSE 0
            END
        ) / NULLIF(SUM(
            CASE 
                WHEN c.units BETWEEN 1 AND 2 THEN 1
                WHEN c.units BETWEEN 3 AND 4 THEN 1.5
                WHEN c.units = 5 THEN 2
                ELSE 0
            END
        ), 0) INTO weighted_avg_score
	FROM "Register" r
	JOIN "Course" c USING(course_code)
	WHERE r.amka = amka_diploma AND r.register_status = 'pass';

	final_diploma_grade := 0.8 * weighted_avg_score + 0.2 * random_diploma_grade;
	INSERT INTO "Diploma" (diploma_num, amkagets, diploma_grade, graduation_date)
	VALUES (id_1, amka_diploma, final_diploma_grade, NOW());
END;

$$ LANGUAGE 'plpgsql' VOLATILE;

SELECT generate_diploma('2015000001','Quantum', 'Why Quantum is pointless');